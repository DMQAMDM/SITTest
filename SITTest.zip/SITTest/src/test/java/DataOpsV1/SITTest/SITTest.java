package DataOpsV1.SITTest;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.AssertJUnit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.testng.annotations.Test;

public class SITTest {

	
	// update your server details e.g. "jdbc:sqlserver://dataops-db.database.windows.net:1433;databaseName=DataMart"
	public String Azure_SQLServer_DM = "jdbc:sqlserver://{YourServerName}.database.windows.net:1433;databaseName=DataOpsDataMart";
	// update your UserID e.g. String UserID = "DataOpsAdmin"
	public String UserID = "{YourUserID}" ;
	// update your Password e.g. String Password = "Password"
	public String Password = "{YourPassword}" ;


	@Test(priority=1)
	public void Verify_record_count_of_Customer_table_matches_with_source() throws Exception {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "select count(*) from dbo.customer";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		int count = resultSet.getInt(1);
		System.out.println(count);

		Assert.assertEquals(847, count);

	}

	
	@Test(priority=2)
	public void Verify_record_count_of_CustomerCount_table_matches_with_source() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "select count(*) from dbo.customercount";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		int count = resultSet.getInt(1);
		System.out.println(count);

		Assert.assertEquals(9, count);
	}
	
	@Test(priority=3)
	public void Verify_record_UpperCase_transformation_FirstName() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "SELECT FirstName FROM [dbo].[Customer] where CustomerID = '1'";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		String value = resultSet.getString(1);
		System.out.println(value);

		Assert.assertEquals("ORLANDO", value);
	}

	
	@Test(priority=4)
	public void Verify_record_LastName_values_are_loaded_correctly() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "SELECT LastName FROM [dbo].[Customer] where CustomerID = '1'";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		String value = resultSet.getString(1);
		System.out.println(value);

		Assert.assertEquals("Gee", value);
	}


	@Test(priority=5)
	public void Verify_record_CompanyName_values_are_loaded_correctly() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "SELECT CompanyName FROM [dbo].[Customer] where CustomerID = '1'";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		String value = resultSet.getString(1);
		System.out.println(value);

		Assert.assertEquals("A Bike Store", value);
	}


	@Test(priority=5)
	public void Verify_record_EmailAddress_values_are_loaded_correctly() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "SELECT EmailAddress FROM [dbo].[Customer] where CustomerID = '1'";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		String value = resultSet.getString(1);
		System.out.println(value);

		Assert.assertEquals("orlando0@adventure-works.com", value);
	}

	@Test(priority=6)
	public void Verify_record_CustomerCount_of_SalesPerson() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "SELECT CustomerCount FROM [dbo].[CustomerCount] where SalesPerson = 'adventure-works\\linda3'";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		String value = resultSet.getString(1);
		System.out.println(value);

		Assert.assertEquals("71", value);
	}
		
	
}
